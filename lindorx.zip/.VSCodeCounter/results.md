# Summary

Date : 2020-05-08 06:51:25

Directory c:\Users\代凡\Documents\代码\system\lindorx

Total : 91 files,  78131 codes, 1679 comments, 1444 blanks, all 81254 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Assembler file | 7 | 72,071 | 0 | 670 | 72,741 |
| C | 26 | 4,084 | 905 | 376 | 5,365 |
| C++ | 49 | 1,788 | 729 | 342 | 2,859 |
| Makefile | 7 | 144 | 44 | 48 | 236 |
| Python | 1 | 41 | 1 | 8 | 50 |
| Markdown | 1 | 3 | 0 | 0 | 3 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 91 | 78,131 | 1,679 | 1,444 | 81,254 |
| app | 1 | 6 | 2 | 1 | 9 |
| bin | 1 | 13 | 2 | 4 | 19 |
| boot | 8 | 1,358 | 8 | 193 | 1,559 |
| dev | 5 | 2,164 | 367 | 195 | 2,726 |
| disasm | 3 | 70,817 | 0 | 494 | 71,311 |
| include | 49 | 1,788 | 729 | 342 | 2,859 |
| include\fs | 6 | 436 | 168 | 54 | 658 |
| obj | 1 | 2 | 0 | 1 | 3 |
| src | 21 | 1,871 | 532 | 181 | 2,584 |

[details](details.md)