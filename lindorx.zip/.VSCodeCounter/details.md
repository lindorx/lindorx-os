# Details

Date : 2020-05-08 06:51:25

Directory c:\Users\代凡\Documents\代码\system\lindorx

Total : 91 files,  78131 codes, 1679 comments, 1444 blanks, all 81254 lines

[summary](results.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Makefile](/Makefile) | Makefile | 109 | 39 | 33 | 181 |
| [README.md](/README.md) | Markdown | 3 | 0 | 0 | 3 |
| [app/start.c](/app/start.c) | C | 6 | 2 | 1 | 9 |
| [bin/makefile](/bin/makefile) | Makefile | 13 | 2 | 4 | 19 |
| [boot/boot.asm](/boot/boot.asm) | Assembler file | 77 | 0 | 16 | 93 |
| [boot/fun32.inc](/boot/fun32.inc) | Assembler file | 394 | 0 | 28 | 422 |
| [boot/head.asm](/boot/head.asm) | Assembler file | 320 | 0 | 25 | 345 |
| [boot/interrupt.inc](/boot/interrupt.inc) | Assembler file | 281 | 0 | 46 | 327 |
| [boot/lk.c](/boot/lk.c) | C | 59 | 7 | 8 | 74 |
| [boot/macro.inc](/boot/macro.inc) | Assembler file | 184 | 0 | 61 | 245 |
| [boot/makefile](/boot/makefile) | Makefile | 2 | 0 | 1 | 3 |
| [boot/mlka.py](/boot/mlka.py) | Python | 41 | 1 | 8 | 50 |
| [dev/int.c](/dev/int.c) | C | 326 | 55 | 29 | 410 |
| [dev/lx.c](/dev/lx.c) | C | 1,796 | 307 | 160 | 2,263 |
| [dev/lxmem.c](/dev/lxmem.c) | C | 17 | 1 | 2 | 20 |
| [dev/lxstack.c](/dev/lxstack.c) | C | 20 | 3 | 2 | 25 |
| [dev/makefile](/dev/makefile) | Makefile | 5 | 1 | 2 | 8 |
| [disasm/bootloder.asm](/disasm/bootloder.asm) | Assembler file | 1,525 | 0 | 5 | 1,530 |
| [disasm/kernel.asm](/disasm/kernel.asm) | Assembler file | 69,290 | 0 | 489 | 69,779 |
| [disasm/makefile](/disasm/makefile) | Makefile | 2 | 0 | 0 | 2 |
| [include/_asm.h](/include/_asm.h) | C++ | 153 | 16 | 23 | 192 |
| [include/cpu.h](/include/cpu.h) | C++ | 19 | 4 | 4 | 27 |
| [include/disk.h](/include/disk.h) | C++ | 3 | 1 | 0 | 4 |
| [include/elf-em.h](/include/elf-em.h) | C++ | 38 | 3 | 2 | 43 |
| [include/elf32.h](/include/elf32.h) | C++ | 120 | 23 | 19 | 162 |
| [include/errno.h](/include/errno.h) | C++ | 6 | 1 | 1 | 8 |
| [include/file.h](/include/file.h) | C++ | 20 | 2 | 3 | 25 |
| [include/fs/glovar.h](/include/fs/glovar.h) | C++ | 53 | 11 | 5 | 69 |
| [include/fs/lx.h](/include/fs/lx.h) | C++ | 166 | 101 | 29 | 296 |
| [include/fs/lxerror.h](/include/fs/lxerror.h) | C++ | 49 | 34 | 4 | 87 |
| [include/fs/lxmem.h](/include/fs/lxmem.h) | C++ | 4 | 1 | 0 | 5 |
| [include/fs/lxstack.h](/include/fs/lxstack.h) | C++ | 4 | 1 | 0 | 5 |
| [include/fs/lxstruct.h](/include/fs/lxstruct.h) | C++ | 160 | 20 | 16 | 196 |
| [include/gdt.h](/include/gdt.h) | C++ | 65 | 9 | 9 | 83 |
| [include/gfp.h](/include/gfp.h) | C++ | 30 | 11 | 25 | 66 |
| [include/idt.h](/include/idt.h) | C++ | 37 | 4 | 4 | 45 |
| [include/initsi.h](/include/initsi.h) | C++ | 27 | 8 | 10 | 45 |
| [include/int.h](/include/int.h) | C++ | 19 | 3 | 7 | 29 |
| [include/lapic.h](/include/lapic.h) | C++ | 2 | 0 | 1 | 3 |
| [include/ldt.h](/include/ldt.h) | C++ | 28 | 25 | 2 | 55 |
| [include/macro.h](/include/macro.h) | C++ | 55 | 16 | 16 | 87 |
| [include/malloc.h](/include/malloc.h) | C++ | 4 | 3 | 1 | 8 |
| [include/math.h](/include/math.h) | C++ | 8 | 5 | 1 | 14 |
| [include/mem.h](/include/mem.h) | C++ | 4 | 8 | 4 | 16 |
| [include/memory.h](/include/memory.h) | C++ | 81 | 36 | 27 | 144 |
| [include/mmu.h](/include/mmu.h) | C++ | 2 | 180 | 3 | 185 |
| [include/mp.h](/include/mp.h) | C++ | 54 | 6 | 8 | 68 |
| [include/page.h](/include/page.h) | C++ | 73 | 35 | 25 | 133 |
| [include/panic.h](/include/panic.h) | C++ | 1 | 0 | 0 | 1 |
| [include/proc.h](/include/proc.h) | C++ | 74 | 13 | 15 | 102 |
| [include/program.h](/include/program.h) | C++ | 2 | 1 | 0 | 3 |
| [include/public.h](/include/public.h) | C++ | 7 | 0 | 1 | 8 |
| [include/radixTree.h](/include/radixTree.h) | C++ | 44 | 19 | 10 | 73 |
| [include/radix_tree.h](/include/radix_tree.h) | C++ | 44 | 21 | 11 | 76 |
| [include/spinlock.h](/include/spinlock.h) | C++ | 16 | 9 | 4 | 29 |
| [include/stack.h](/include/stack.h) | C++ | 12 | 8 | 0 | 20 |
| [include/stdio.h](/include/stdio.h) | C++ | 2 | 1 | 1 | 4 |
| [include/stdlib.h](/include/stdlib.h) | C++ | 2 | 1 | 0 | 3 |
| [include/string.h](/include/string.h) | C++ | 8 | 4 | 3 | 15 |
| [include/sys_struct.h](/include/sys_struct.h) | C++ | 60 | 35 | 4 | 99 |
| [include/syscall.h](/include/syscall.h) | C++ | 2 | 1 | 1 | 4 |
| [include/sysio.h](/include/sysio.h) | C++ | 42 | 16 | 12 | 70 |
| [include/task.h](/include/task.h) | C++ | 44 | 11 | 13 | 68 |
| [include/test.h](/include/test.h) | C++ | 2 | 0 | 0 | 2 |
| [include/time.h](/include/time.h) | C++ | 43 | 5 | 6 | 54 |
| [include/traps.h](/include/traps.h) | C++ | 27 | 6 | 6 | 39 |
| [include/tss.h](/include/tss.h) | C++ | 46 | 6 | 2 | 54 |
| [include/type.h](/include/type.h) | C++ | 13 | 0 | 4 | 17 |
| [include/vadefs.h](/include/vadefs.h) | C++ | 13 | 5 | 0 | 18 |
| [obj/makefile](/obj/makefile) | Makefile | 2 | 0 | 1 | 3 |
| [src/file.c](/src/file.c) | C | 20 | 6 | 5 | 31 |
| [src/gdt.c](/src/gdt.c) | C | 55 | 7 | 2 | 64 |
| [src/initsi.c](/src/initsi.c) | C | 67 | 18 | 15 | 100 |
| [src/lock.c](/src/lock.c) | C | 9 | 2 | 2 | 13 |
| [src/main.c](/src/main.c) | C | 32 | 24 | 3 | 59 |
| [src/makefile](/src/makefile) | Makefile | 11 | 2 | 7 | 20 |
| [src/malloc.c](/src/malloc.c) | C | 55 | 67 | 9 | 131 |
| [src/math.c](/src/math.c) | C | 68 | 7 | 6 | 81 |
| [src/memory.c](/src/memory.c) | C | 271 | 103 | 30 | 404 |
| [src/page.c](/src/page.c) | C | 182 | 93 | 14 | 289 |
| [src/panic.c](/src/panic.c) | C | 8 | 0 | 0 | 8 |
| [src/proc.c](/src/proc.c) | C | 92 | 56 | 22 | 170 |
| [src/program.c](/src/program.c) | C | 21 | 12 | 2 | 35 |
| [src/public.c](/src/public.c) | C | 6 | 0 | 1 | 7 |
| [src/radix_tree.c](/src/radix_tree.c) | C | 236 | 13 | 10 | 259 |
| [src/stack.c](/src/stack.c) | C | 44 | 7 | 8 | 59 |
| [src/stdio.c](/src/stdio.c) | C | 18 | 2 | 3 | 23 |
| [src/string.c](/src/string.c) | C | 64 | 6 | 3 | 73 |
| [src/sysio.c](/src/sysio.c) | C | 318 | 52 | 14 | 384 |
| [src/task.c](/src/task.c) | C | 188 | 39 | 21 | 248 |
| [src/time.c](/src/time.c) | C | 106 | 16 | 4 | 126 |

[summary](results.md)