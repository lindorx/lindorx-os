void init_lapic(void);
int lapicid(void);
