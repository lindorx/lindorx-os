#pragma once
//stdlib.h内的函数声明
#include<malloc.h>