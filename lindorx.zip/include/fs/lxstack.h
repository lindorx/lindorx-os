#pragma once
#include<fs/glovar.h>
tree_error dalloc_bmp_spush(uint32 i, uint32 blocks);
//将被改动的位图块加入堆栈
tree_error DataBMP_Stack_Push(uint32 n);