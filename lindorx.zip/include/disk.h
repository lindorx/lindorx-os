extern unsigned int _DEV_HARD_DISK_;
//_DEV_HARD_DISK_的变量
#define __DEV_MAIN_HD           0       //主盘
#define __DEV_SLAVE_HD          1       //从盘