#pragma once
#include<sys_struct.h>
extern BOOTLoder sys_bootloder;

enum pubval{
        _DISPLAY_MODE,//显示模式
        _DISPLAY_ADDR//显示地址
};