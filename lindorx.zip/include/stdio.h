#pragma once
#include<file.h>
//式样化字符输出函数
int printf(const char *format, ...);
int puts(const char* string);