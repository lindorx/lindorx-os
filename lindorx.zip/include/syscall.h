#include<int.h>
#define syscall_fork 2

//extern void syscall(void);