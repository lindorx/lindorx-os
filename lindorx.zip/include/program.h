#pragma once
//第一个程序
void initpro();